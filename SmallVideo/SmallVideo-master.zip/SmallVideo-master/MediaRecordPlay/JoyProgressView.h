//
//  JoyProgressView.h
//  LW
//
//  Created by wangguopeng on 2017/5/16.
//  Copyright © 2017年 joymake. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JoyProgressView : UIView
@property (nonatomic,assign)CGFloat progress;
@end
