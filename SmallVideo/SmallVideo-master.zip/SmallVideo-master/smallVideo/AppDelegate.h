//
//  AppDelegate.h
//  smallVideo
//
//  Created by wangguopeng on 2017/6/16.
//  Copyright © 2017年 joymake. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

